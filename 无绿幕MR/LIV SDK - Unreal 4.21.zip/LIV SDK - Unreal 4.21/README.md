# LIV SDK v0.1.0 for Unreal

## Quick Start

1. Create a folder called `Plugins` in your Unreal project's folder.
2. Copy the folder `LIV` into this folder.
3. If your Unreal project doesn't have any C++ code, add a new empty class. (File > New C++ Class...)
4. Edit your `Pawn` blueprint.
5. In the hierarchy next to your `Camera` add `LIV > MixedRealityRenderer`.
6. In your project settings, enable the option `Support global clip plane for Planar Reflections`.

Restart your editor as requested, and that's it!

## Testing

**Note**: These instructions are the minimum you need to check if your integration worked.

**We suggest testing with a packaged build of your application!**

- Download the [LIV App]( https://liv.tv/download#liv-app ).
- Run it, install the Virtual Camera driver.
- In LIV, launch the compositor.
- Run your project.
- Using "Manual" capture mode, pick your project from the list.

If all has gone well, you'll see your application in LIV's output! Without a camera calibration you will most likely see the sky, so unless your skybox is black - not seeing black in the compositor is a good "sanity check" for whether or not it's working!

## Packaging

### Unreal 4.15 & 4.16

It's likely that when you package for these engines you'll get an error: `PackagingResults:Error: Error Unknown Cook Failure`.

**The fix**: Delete `CombineAlpha.uasset` & `CustomTonemapper.uasset` from the `Plugins\LIV\Content` folder. Leave the `Legacy` folder as-is!

## Next Steps

If your application is being published to Steam, you should next contact us (see below) and let us know more about what you're working on! We'll add your application to our official supported list after testing your integration, and we can work with you to get it in front of creators.

If you're just looking to get some footage from your application, next up you'll want to set up the LIV App as normal. See our [Wiki]( http://liv.wiki/ ) for general setup steps.  
If your application isn't showing in the automatic area of LIV, then you'll likely need to export your configuration manually. This file needs to go either next to your `.uproject`, or next to your packaged executable (`WindowsNoEditor`, next to the `Engine` folder and your app folder). This config file **must** be named either `liv-camera.cfg` or `externalcamera.cfg`.

## Further Help & Feedback

We want to hear your ideas, plans, and what you're going to end up doing with the SDK - if you've got an exotic idea that you might need a hand with - reach out. We're just as enthusiastic as you <3

We're always available through our [Discord Community]( http://liv.chat ), so please pop in if you need help. If you're not familiar with Discord, it's a popular gaming-oriented instant messenger & VOIP client.

Alternately, you can email us through techteam@liv.tv!
