#pragma once

#include <CoreMinimal.h>
#include <Engine/CanvasRenderTarget2D.h>
#include <Materials/MaterialInstanceDynamic.h>
#include "MixedRealityCanvas.generated.h"

UCLASS()
class LIV_API UMixedRealityCanvas : public UCanvasRenderTarget2D
{
	GENERATED_BODY()

public:
	UMixedRealityCanvas();

	void UpdateResource() override;

	UPROPERTY(EditInstanceOnly, BlueprintReadWrite)
		UTextureRenderTarget2D* BackgroundTexture;

	UPROPERTY(EditInstanceOnly, BlueprintReadWrite)
		UTextureRenderTarget2D* ForegroundTexture;

	UPROPERTY(EditInstanceOnly, BlueprintReadWrite)
		UTextureRenderTarget2D* PostprocessedForegroundTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UMaterialInstanceDynamic* BG_Tonemapper;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UMaterialInstanceDynamic* FG_Tonemapper;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UMaterialInstanceDynamic* FG_CombineAlpha;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool bPostprocessBackground;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool bPostprocessForeground;

	void UpdateMaterialsTextures() const;

protected:
	UFUNCTION()
		void OnRender(UCanvas* Canvas, int32 Width, int32 Height);
};
