#include "Compatibility.h"

vr::IVRCompositor* LIVCompatibility::OpenVRInterfaceCompositor;
vr::IVRSystem* LIVCompatibility::OpenVRInterfaceSystem;