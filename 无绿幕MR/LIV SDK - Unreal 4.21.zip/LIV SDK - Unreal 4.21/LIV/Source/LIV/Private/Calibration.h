#pragma once

#include <CoreMinimal.h>
#include <GameFramework/Actor.h>
#include "Calibration.generated.h"

UCLASS()
class ACalibration : public AActor
{
	GENERATED_BODY()

public:
	ACalibration();

protected:
	void BeginPlay() override;

	FString GetConfigDir() const;

	static FString TrimCalibrationLine(FString CalibrationLine);

public:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
		bool IsConfigAvailable;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
		FVector LocationOffset;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
		FRotator RotationOffset;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
		float FOV;

	UFUNCTION(BlueprintCallable, Category = "LIV")
		bool ReadConfig();
};
