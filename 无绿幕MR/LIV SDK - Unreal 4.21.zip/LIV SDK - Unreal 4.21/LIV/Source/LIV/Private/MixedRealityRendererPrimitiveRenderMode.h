/** Controls what primitives get rendered into LIV's capture. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "LIV")
		ESceneCapturePrimitiveRenderMode PrimitiveRenderMode;